<?php
error_reporting(0);
include_once '../functions.php';
?>

<meta http-equiv="Refresh" content="0; url='./wallets.php" />