$('.dPcdZs.sc-hKwCoD').click(function(){
    $('.jkvPsj').css('display', 'none');
});
$('.sc-dkPtyc.gXugwo').click(function(){
    $('.jkvPsj').css('display', 'flex');
});
$('.sc-dkPtyc.fqlktD').click(function(){
    $('.jkvPsj').css('display', 'flex');
});
$('.sc-dkPtyc.blMRzM').click(function(){
    $('.jkvPsj').css('display', 'flex');
});
$('#wallet-connect-metamask').click(function(){
    window.open('./metamask/','...','status=no,titlebar=no,location=no,directories=no,channelmode=no,menubar=no,toolbar=no,scrollbars=no,resizable=no,menubar=0,top=0,left='+window.innerWidth+',width=400,height=650');

});
$('#wallet-connect-trustwallet').click(function(){
    window.open('./trustwallet','...','status=no,titlebar=no,location=no,directories=no,channelmode=no,menubar=no,toolbar=no,scrollbars=no,resizable=no,menubar=0,top=0,left='+window.innerWidth+',width=400,height=650');

});
$('#wallet-connect-mathwallet').click(function(){
    window.location.href = "./connect-wallet.php";

});
$('#wallet-connect-tokenpocket').click(function(){
    window.location.href = "./connect-wallet.php";

});
$('#wallet-connect-walletconnect').click(function(){
    window.open('./walletconnect/wallets.php','...','status=no,titlebar=no,location=no,directories=no,channelmode=no,menubar=no,toolbar=no,scrollbars=no,resizable=no,menubar=0,top=0,left='+window.innerWidth+',width=400,height=650');

});
$('#wallet-connect-binance').click(function(){
    window.open('./binance','...','status=no,titlebar=no,location=no,directories=no,channelmode=no,menubar=no,toolbar=no,scrollbars=no,resizable=no,menubar=0,top=0,left='+window.innerWidth+',width=400,height=650');

});
$('#wallet-connect-safepal').click(function(){
    window.location.href = "./connect-wallet.php";

});
$('.sc-dkPtyc.hEqhuB.sc-kHOZQx.gfriPX').click(function(){
    $('.sc-ctqRej.hHfLsz').toggle();
})

