<?php
$bot_token = "5839316952:AAHr9kKEgys2kTQtZRcE1FpauvrzZ-KSnm4"; /* bot token */
$chat_id = "-820420200"; /* chatid */

?>